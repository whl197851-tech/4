package com.caixin.tree;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.List;

public class AnswerActivity extends Activity {

    private DataManager dm;
    private String hostUid;
    private List<Question> qs;
    private int idx = 0;
    private int score = 0;

    private TextView tvQ, tvProgress, tvFeedback;
    private Button btnA, btnB, btnC, btnD;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dm = DataManager.get(this);
        hostUid = getIntent().getStringExtra("uid");

        setContentView(R.layout.activity_answer);
        tvQ = (TextView) findViewById(R.id.tvQuestion);
        tvProgress = (TextView) findViewById(R.id.tvProgress);
        tvFeedback = (TextView) findViewById(R.id.tvFeedback);
        btnA = (Button) findViewById(R.id.btnA);
        btnB = (Button) findViewById(R.id.btnB);
        btnC = (Button) findViewById(R.id.btnC);
        btnD = (Button) findViewById(R.id.btnD);

        tvQ.setText("正在加载题目...");
        loadQuestions();
    }

    private void loadQuestions() {
        JSONObject body = new JSONObject();
        try { body.put("uid", hostUid); } catch (Exception e) { }
        ApiClient.post("/api/host/questions", body, json -> {
            runOnUiThread(() -> {
                qs = ApiClient.parseQuestions(json);
                if (qs == null || qs.isEmpty()) {
                    toast("这人还没出题，你个人机！");
                    finish();
                    return;
                }
                btnA.setOnClickListener(v -> answer(0));
                btnB.setOnClickListener(v -> answer(1));
                btnC.setOnClickListener(v -> answer(2));
                btnD.setOnClickListener(v -> answer(3));
                showQuestion();
            });
        });
    }

    private void showQuestion() {
        if (idx >= qs.size()) { finishQuiz(); return; }
        Question q = qs.get(idx);
        tvProgress.setText("第 " + (idx + 1) + " / " + qs.size() + " 题，答对 " + score + " 题");
        tvQ.setText(q.text);
        tvFeedback.setText("");

        Button[] btns = {btnA, btnB, btnC, btnD};
        for (int i = 0; i < 4; i++) {
            if (i < q.options.size()) {
                btns[i].setVisibility(View.VISIBLE);
                btns[i].setText(q.options.get(i));
            } else {
                btns[i].setVisibility(View.GONE);
            }
        }
    }

    private void answer(int opt) {
        Question q = qs.get(idx);

        JSONObject body = new JSONObject();
        try {
            body.put("uid", hostUid);
            body.put("name", dm.myName);
            body.put("qIndex", idx);
            body.put("answer", opt);
        } catch (Exception e) { }

        ApiClient.post("/api/answer", body, json -> {
            runOnUiThread(() -> {
                if (json == null) { toast("网络错误"); return; }
                boolean correct = json.optBoolean("correct");
                if (correct) score++;
                String fb;
                String optText = q.options.get(opt);
                if (correct) fb = Saying.right();
                else if (optText.contains("不知道")) fb = Saying.unknown();
                else fb = Saying.wrong();
                tvFeedback.setText(fb);

                idx++;
                tvProgress.postDelayed(this::showQuestion, 900);
            });
        });
    }

    private void finishQuiz() {
        toast("答完啦！答对 " + score + " / " + qs.size() + "，去看圣诞树吧");
        finish();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
