package com.caixin.tree;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.List;

/** 圣诞树: 答对越多挂得越高, 答错掉树底 */
public class ChristmasTreeView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Player> players;

    public ChristmasTreeView(Context c) {
        super(c);
    }

    public void setPlayers(List<Player> p) {
        this.players = p;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        int w = getWidth();
        int h = getHeight();

        // 天空
        paint.setColor(Color.parseColor("#0E1A12"));
        cv.drawRect(0, 0, w, h, paint);

        // 雪花点
        paint.setColor(0x66FFFFFF);
        for (int i = 0; i < 60; i++) {
            float x = (i * 37.7f) % w;
            float y = (i * 53.3f) % h;
            cv.drawCircle(x, y, 2, paint);
        }

        // 树干
        paint.setColor(Color.parseColor("#7A4A21"));
        cv.drawRect(w / 2 - 20, h - 140, w / 2 + 20, h - 20, paint);

        // 树冠(3层三角)
        int topY = 80;
        int bottomY = h - 120;
        paint.setColor(Color.parseColor("#1B7A3D"));
        float cx = w / 2;
        // 底层
        cv.drawPath(makeTriangle(cx - w * 0.42f, bottomY, cx + w * 0.42f, bottomY, cx, topY + 220), paint);
        // 中层
        paint.setColor(Color.parseColor("#2E8B57"));
        cv.drawPath(makeTriangle(cx - w * 0.34f, bottomY - 90, cx + w * 0.34f, bottomY - 90, cx, topY + 100), paint);
        // 顶层
        paint.setColor(Color.parseColor("#3CB371"));
        cv.drawPath(makeTriangle(cx - w * 0.26f, bottomY - 180, cx + w * 0.26f, bottomY - 180, cx, topY), paint);

        // 树顶星星
        paint.setColor(Color.parseColor("#FFD700"));
        cv.drawCircle(cx, topY - 10, 14, paint);

        // 玩家小圆点挂树: 答对率越高越靠上
        if (players != null) {
            paint.setTextSize(30);
            paint.setTextAlign(Paint.Align.CENTER);
            for (Player p : players) {
                float ratio = p.answered == 0 ? 0 : (float) p.score / p.answered;
                float y = bottomY - ratio * (bottomY - topY - 40);
                float spread = (1 - ratio) * w * 0.42f;
                float x = cx + (float) Math.sin(p.uid.hashCode()) * spread * 0.5f;

                // 彩球
                int color = p.score == p.answered ? Color.parseColor("#FFD700")
                        : (ratio > 0.5f ? Color.parseColor("#FF6B6B") : Color.parseColor("#888888"));
                paint.setColor(color);
                cv.drawCircle(x, y, 18, paint);
                paint.setColor(Color.WHITE);
                cv.drawText(p.name, x, y + 45, paint);
            }
        }

        // 底部文字
        paint.setTextSize(26);
        paint.setColor(Color.WHITE);
        cv.drawText("答对越多，挂得越高 ↑", cx, h - 40, paint);
    }

    private android.graphics.Path makeTriangle(float x0, float y0, float x1, float y1, float xTop, float yTop) {
        android.graphics.Path p = new android.graphics.Path();
        p.moveTo(x0, y0);
        p.lineTo(x1, y1);
        p.lineTo(xTop, yTop);
        p.close();
        return p;
    }
}
