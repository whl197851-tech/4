package com.caixin.tree;

import android.content.Context;
import android.content.SharedPreferences;

/** 联网版数据层: 本地只存自己的 uid/name, 其余走服务器 */
public class DataManager {

    private static DataManager inst;
    private Context ctx;
    private SharedPreferences sp;

    public String myUid = "";
    public String myName = "";
    public int nameChangeCount = 0;

    public static DataManager get(Context c) {
        if (inst == null) inst = new DataManager(c.getApplicationContext());
        return inst;
    }

    private DataManager(Context c) {
        ctx = c;
        sp = c.getSharedPreferences("caixin_online", Context.MODE_PRIVATE);
        myUid = sp.getString("uid", "");
        myName = sp.getString("name", "");
        nameChangeCount = sp.getInt("change", 0);
    }

    public boolean hasLogin() {
        return !myUid.isEmpty();
    }

    public void saveLogin(String uid, String name) {
        myUid = uid;
        myName = name;
        sp.edit().putString("uid", uid).putString("name", name).apply();
    }

    public void saveNameChangeCount(int n) {
        nameChangeCount = n;
        sp.edit().putInt("change", n).apply();
    }
}
