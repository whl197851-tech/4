package com.caixin.tree;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/** 后端接口封装 */
public class ApiClient {

    // 改成你服务器的地址
    public static String BASE = "http://10.0.2.2:3000";

    public interface Callback {
        void onResult(JSONObject json);
    }

    public static void post(String path, JSONObject body, Callback cb) {
        new AsyncTask<Void, Void, JSONObject>() {
            protected JSONObject doInBackground(Void... v) {
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(BASE + path).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(5000);
                    c.setReadTimeout(8000);
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json");
                    OutputStream os = c.getOutputStream();
                    os.write(body.toString().getBytes("UTF-8"));
                    os.close();
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    return new JSONObject(sb.toString());
                } catch (Exception e) {
                    return null;
                } finally {
                    if (c != null) c.disconnect();
                }
            }
            protected void onPostExecute(JSONObject j) {
                cb.onResult(j);
            }
        }.execute();
    }

    public static void get(String path, Callback cb) {
        new AsyncTask<Void, Void, JSONObject>() {
            protected JSONObject doInBackground(Void... v) {
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(BASE + path).openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(5000);
                    c.setReadTimeout(8000);
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    return new JSONObject(sb.toString());
                } catch (Exception e) {
                    return null;
                } finally {
                    if (c != null) c.disconnect();
                }
            }
            protected void onPostExecute(JSONObject j) {
                cb.onResult(j);
            }
        }.execute();
    }

    /** JSON -> 题目列表 */
    public static List<Question> parseQuestions(JSONObject json) {
        List<Question> list = new ArrayList<>();
        try {
            JSONArray arr = json.getJSONArray("questions");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Question q = new Question();
                q.text = o.getString("text");
                q.answer = o.getInt("answer");
                q.options = new ArrayList<>();
                JSONArray opts = o.getJSONArray("options");
                for (int j = 0; j < opts.length(); j++) q.options.add(opts.getString(j));
                list.add(q);
            }
        } catch (Exception e) { }
        return list;
    }

    /** JSON -> 排行榜玩家列表 */
    public static List<Player> parsePlayers(JSONObject json) {
        List<Player> list = new ArrayList<>();
        try {
            JSONArray arr = json.getJSONArray("players");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Player p = new Player();
                p.name = o.getString("name");
                p.score = o.getInt("score");
                p.answered = o.getInt("answered");
                list.add(p);
            }
        } catch (Exception e) { }
        return list;
    }
}
