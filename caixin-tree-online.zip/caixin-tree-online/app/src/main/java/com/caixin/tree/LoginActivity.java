package com.caixin.tree;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class LoginActivity extends Activity {

    private EditText etName, etPass;
    private TextView tvHint;
    private DataManager dm;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dm = DataManager.get(this);

        // 已登录直接进主页
        if (dm.hasLogin()) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_login);
        etName = (EditText) findViewById(R.id.etName);
        etPass = (EditText) findViewById(R.id.etPass);
        tvHint = (TextView) findViewById(R.id.tvHint);
        Button btn = (Button) findViewById(R.id.btnLogin);

        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { doLogin(); }
        });
    }

    private void doLogin() {
        String name = etName.getText().toString().trim();
        String pass = etPass.getText().toString().trim();

        if (TextUtils.isEmpty(name)) { tvHint.setText("名字不能为空哦"); return; }
        if (!pass.equals("HSNB666")) { tvHint.setText("密码错啦，你个人机！"); return; }

        btnLoading();
        JSONObject body = new JSONObject();
        try { body.put("name", name); } catch (Exception e) { }

        ApiClient.post("/api/register", body, json -> {
            if (json != null && json.optBoolean("ok")) {
                dm.saveLogin(json.optString("uid"), json.optString("name"));
                runOnUiThread(() -> {
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                });
            } else {
                runOnUiThread(() -> {
                    tvHint.setText("登录失败，检查服务器地址");
                    btnNormal();
                });
            }
        });
    }

    private void btnLoading() {
        ((Button) findViewById(R.id.btnLogin)).setText("登录中...");
    }
    private void btnNormal() {
        ((Button) findViewById(R.id.btnLogin)).setText("登录");
    }
}
