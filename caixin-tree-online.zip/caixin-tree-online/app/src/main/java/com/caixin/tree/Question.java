package com.caixin.tree;

import java.io.Serializable;
import java.util.List;

/** 一道题 */
public class Question implements Serializable {
    public String text;            // 题目
    public List<String> options;   // 选项
    public int answer;             // 正确选项索引(0起)
}
