package com.caixin.tree;

import java.io.Serializable;

/** 一个答题者 */
public class Player implements Serializable {
    public String name;
    public String uid;
    public int score = 0;          // 答对题数
    public int answered = 0;       // 已答题数
    public String hostUid = "";    // 回答的是谁的题
    public String lastSaying = "";
}
