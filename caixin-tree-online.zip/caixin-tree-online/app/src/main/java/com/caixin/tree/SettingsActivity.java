package com.caixin.tree;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class SettingsActivity extends Activity {

    private DataManager dm;
    private TextView tvName, tvUid, tvChange;
    private EditText etNewName;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dm = DataManager.get(this);
        setContentView(R.layout.activity_settings);

        tvName = (TextView) findViewById(R.id.tvName);
        tvUid = (TextView) findViewById(R.id.tvUid);
        tvChange = (TextView) findViewById(R.id.tvChange);
        etNewName = (EditText) findViewById(R.id.etNewName);

        ((Button) findViewById(R.id.btnRename)).setOnClickListener(v -> rename());
        ((Button) findViewById(R.id.btnWallpaper)).setOnClickListener(v -> pickWallpaper());
        ((Button) findViewById(R.id.btnClearWallpaper)).setOnClickListener(v -> clearWallpaper());

        refresh();
    }

    private void refresh() {
        tvName.setText("名字: " + dm.myName);
        tvUid.setText("我的 UID: " + dm.myUid + "\n(把这个告诉别人，他们就能搜到你)");
        tvChange.setText(dm.nameChangeCount >= 1
                ? "名字已改过一次，不能再改了"
                : "你还有 1 次改名字的机会");
    }

    private void rename() {
        String n = etNewName.getText().toString().trim();
        if (TextUtils.isEmpty(n)) { toast("新名字不能为空"); return; }

        JSONObject body = new JSONObject();
        try { body.put("uid", dm.myUid); body.put("name", n); } catch (Exception e) { }

        ApiClient.post("/api/rename", body, json -> {
            runOnUiThread(() -> {
                if (json != null && json.optBoolean("ok")) {
                    dm.myName = n;
                    dm.saveNameChangeCount(dm.nameChangeCount + 1);
                    etNewName.setText("");
                    refresh();
                    toast("改名成功！");
                } else {
                    toast("改不了：名字只能改一次");
                }
            });
        });
    }

    private void pickWallpaper() {
        Intent it = new Intent(Intent.ACTION_PICK);
        it.setType("image/*");
        startActivityForResult(it, 100);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 100 && res == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception e) { }
                getSharedPreferences("caixin", MODE_PRIVATE).edit()
                        .putString("wallpaper", uri.toString()).apply();
                toast("壁纸已设置，回主页看看！");
            }
        }
    }

    private void clearWallpaper() {
        getSharedPreferences("caixin", MODE_PRIVATE).edit()
                .remove("wallpaper").apply();
        toast("已恢复默认背景");
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
