package com.caixin.tree;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class TreeActivity extends Activity {

    private DataManager dm;
    private String uid;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dm = DataManager.get(this);

        uid = getIntent().getStringExtra("uid");
        if (uid == null || uid.isEmpty()) uid = dm.myUid;

        setContentView(R.layout.activity_tree);
        TextView tvHost = (TextView) findViewById(R.id.tvHost);
        tvHost.setText("UID:" + uid + " 的圣诞树");

        loadTree();

        ((Button) findViewById(R.id.btnJoin)).setOnClickListener(v -> {
            Intent it = new Intent(this, AnswerActivity.class);
            it.putExtra("uid", uid);
            startActivity(it);
        });
    }

    private void loadTree() {
        ApiClient.get("/api/host/tree?uid=" + uid, json -> {
            runOnUiThread(() -> {
                if (json == null || !json.optBoolean("ok")) {
                    toast("没找到这人，你个人机！");
                    return;
                }
                TextView tvHost = (TextView) findViewById(R.id.tvHost);
                String name = json.optJSONObject("host") != null
                        ? json.optJSONObject("host").optString("name") : "";
                tvHost.setText(name + " 的圣诞树 (UID:" + uid + ")");

                List<Player> list = ApiClient.parsePlayers(json);
                ChristmasTreeView tree = (ChristmasTreeView) findViewById(R.id.treeView);
                tree.setPlayers(list);
            });
        });
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
