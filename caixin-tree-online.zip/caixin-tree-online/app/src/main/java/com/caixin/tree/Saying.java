package com.caixin.tree;

import java.util.Random;

/** 搞笑反馈词库 */
public class Saying {
    private static final Random R = new Random();

    private static final String[] RIGHT = {
        "卧槽？你是我肚子里的蛔虫吧！",
        "猜这么准，你是不是偷看我日记了！",
        "可以啊兄弟，这都能对，有点东西。",
        "你懂我！原地结拜吧。",
        "？？？这么了解我，我有点慌。",
        "稳！就冲这题，挂你上去看星星。",
        "好家伙，知音啊，加鸡腿！",
        "这都能中，你开挂了吧。",
        "对咯，以后我发朋友圈你来点赞。",
        "行，算你懂我，记你一功。",
    };

    private static final String[] WRONG = {
        "你个人机！",
        "哈哈哈，你完全不懂我啊。",
        "错得离谱，罚你去扫地。",
        "就这？就这？我还以为你很懂。",
        "你怕不是来搞笑的。",
        "错！你跟我八字不合。",
        "天呐，这都选错，凉了。",
        "你走吧，我不认识你。",
        "错啦！挂树底下抱树根吧。",
        "啊这……你换个星球生活吧。",
    };

    private static final String[] UNKNOWN = {
        "不知道就直说，不丢人～",
        "选不知道是吧，行，诚实分给你。",
        "不知道啊？那你上去挂个问号吧。",
        "好，不知道也算一种答案。",
    };

    public static String right() { return RIGHT[R.nextInt(RIGHT.length)]; }
    public static String wrong() { return WRONG[R.nextInt(WRONG.length)]; }
    public static String unknown() { return UNKNOWN[R.nextInt(UNKNOWN.length)]; }
}
