package com.caixin.tree;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class QuizCreateActivity extends Activity {

    private DataManager dm;
    private EditText etQ, etA, etB, etC, etD;
    private TextView tvCount, tvList;
    private int selectedAnswer = 0;
    private Button[] ansBtns = new Button[4];
    private int count = 0;
    private StringBuilder listText = new StringBuilder();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dm = DataManager.get(this);
        setContentView(R.layout.activity_quiz);

        etQ = (EditText) findViewById(R.id.etQuestion);
        etA = (EditText) findViewById(R.id.etOptA);
        etB = (EditText) findViewById(R.id.etOptB);
        etC = (EditText) findViewById(R.id.etOptC);
        etD = (EditText) findViewById(R.id.etOptD);
        tvCount = (TextView) findViewById(R.id.tvCount);
        tvList = (TextView) findViewById(R.id.tvList);

        ansBtns[0] = (Button) findViewById(R.id.btnAnsA);
        ansBtns[1] = (Button) findViewById(R.id.btnAnsB);
        ansBtns[2] = (Button) findViewById(R.id.btnAnsC);
        ansBtns[3] = (Button) findViewById(R.id.btnAnsD);

        for (int i = 0; i < 4; i++) {
            final int idx = i;
            ansBtns[i].setOnClickListener(v -> setAnswer(idx));
        }

        ((Button) findViewById(R.id.btnAdd)).setOnClickListener(v -> addQuestion());
        ((Button) findViewById(R.id.btnDone)).setOnClickListener(v -> done());

        refresh();
    }

    private void setAnswer(int idx) {
        selectedAnswer = idx;
        for (int i = 0; i < 4; i++) {
            ansBtns[i].setBackgroundColor(i == idx ? Color.parseColor("#D4AF37") : Color.parseColor("#555555"));
        }
    }

    private void addQuestion() {
        String q = etQ.getText().toString().trim();
        List<String> opts = new ArrayList<>();
        opts.add(etA.getText().toString().trim());
        opts.add(etB.getText().toString().trim());
        String c = etC.getText().toString().trim();
        String d = etD.getText().toString().trim();
        if (!TextUtils.isEmpty(c)) opts.add(c);
        if (!TextUtils.isEmpty(d)) opts.add(d);

        if (TextUtils.isEmpty(q) || opts.get(0).isEmpty() || opts.get(1).isEmpty()) {
            toast("题目和 A、B 选项都要填哦");
            return;
        }
        if (count >= 100) { toast("最多 100 题，已经满了！"); return; }

        JSONObject body = new JSONObject();
        try {
            body.put("uid", dm.myUid);
            body.put("text", q);
            body.put("options", new JSONArray(opts));
            body.put("answer", selectedAnswer < opts.size() ? selectedAnswer : 0);
        } catch (Exception e) { }

        ApiClient.post("/api/host/add", body, json -> {
            runOnUiThread(() -> {
                if (json != null && json.optBoolean("ok")) {
                    count++;
                    listText.append(count).append(". ").append(q).append("\n");
                    etQ.setText(""); etA.setText(""); etB.setText("");
                    etC.setText(""); etD.setText("");
                    refresh();
                    toast("已添加！当前 " + count + " 题");
                } else {
                    toast("添加失败，检查服务器");
                }
            });
        });
    }

    private void done() {
        toast("出题完成！共 " + count + " 题，别人搜你 UID 就能答");
        finish();
    }

    private void refresh() {
        tvCount.setText("已出题: " + count + " 题");
        tvList.setText(listText.toString());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
