package com.caixin.tree;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONObject;

/** 版本更新检查弹窗 */
public class UpdateChecker {

    public static void check(Context ctx) {
        ApiClient.get("/api/version", json -> {
            if (json == null) return;
            try {
                String ver = json.getString("version");
                String url = json.getString("url");
                String cur = "1.0.1";
                if (!ver.equals(cur)) {
                    new AlertDialog.Builder(ctx)
                            .setTitle("发现新版本 " + ver)
                            .setMessage("是否去更新？")
                            .setPositiveButton("更新", (d, w) -> {
                                try {
                                    ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                                } catch (Exception e) { }
                            })
                            .setNegativeButton("以后再说", null)
                            .show();
                }
            } catch (Exception e) { }
        });
    }
}
