package com.caixin.tree;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;

public class MainActivity extends Activity {

    private DataManager dm;
    private LinearLayout content;
    private EditText etSearch;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dm = DataManager.get(this);
        setContentView(R.layout.activity_main);

        etSearch = (EditText) findViewById(R.id.etSearch);
        content = (LinearLayout) findViewById(R.id.content);

        ((Button) findViewById(R.id.btnSearch)).setOnClickListener(v -> search());
        ((Button) findViewById(R.id.navHome)).setOnClickListener(v -> showHome());
        ((Button) findViewById(R.id.navPlay)).setOnClickListener(v ->
                startActivity(new Intent(this, QuizCreateActivity.class)));
        ((Button) findViewById(R.id.navTree)).setOnClickListener(v ->
                startActivity(new Intent(this, TreeActivity.class)));
        ((Button) findViewById(R.id.navSet)).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        applyWallpaper();
        showHome();
        UpdateChecker.check(this);   // 检查更新弹窗
    }

    private void applyWallpaper() {
        String path = getSharedPreferences("caixin", MODE_PRIVATE)
                .getString("wallpaper", "");
        if (!path.isEmpty()) {
            try {
                InputStream in = getContentResolver().openInputStream(Uri.parse(path));
                Bitmap bm = BitmapFactory.decodeStream(in);
                if (bm != null) {
                    FrameLayout root = (FrameLayout) findViewById(R.id.frameRoot);
                    root.setBackground(new BitmapDrawable(getResources(), bm));
                }
            } catch (Exception e) { }
        }
    }

    private void search() {
        String uid = etSearch.getText().toString().trim();
        if (uid.isEmpty()) { toast("先输入UID"); return; }
        Intent it = new Intent(this, TreeActivity.class);
        it.putExtra("uid", uid);
        startActivity(it);
    }

    private void showHome() {
        content.removeAllViews();
        TextView title = new TextView(this);
        title.setText("欢迎回来，" + dm.myName + " 🎄");
        title.setTextSize(22);
        title.setTextColor(0xFFFFFFFF);
        content.addView(title);

        TextView uid = new TextView(this);
        uid.setText("你的UID: " + dm.myUid + "\n(别人搜这个就能看你的圣诞树)");
        uid.setTextSize(14);
        uid.setTextColor(0xFFD4AF37);
        uid.setPadding(0, 12, 0, 0);
        content.addView(uid);

        TextView tip = new TextView(this);
        tip.setText("玩法说明:\n你是楼主，在「玩法」里出题(1~100题)。\n别人搜你UID答题，答对越多，在你的圣诞树上挂得越高，答错就掉到树底抱树根～");
        tip.setTextSize(15);
        tip.setTextColor(0xFFAAAAAA);
        tip.setPadding(0, 24, 0, 0);
        content.addView(tip);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
