# 「猜心圣诞树」联网版 · 手机免费出 APK 教程

## 第一步：先部署后端（有服务器才有联网）

见同目录《后端部署教程.md》，先拿到你的服务器地址，比如
`https://你的应用.onrender.com`

## 第二步：把服务器地址填进 App

用文本编辑器（MT管理器也行）打开：
`app/src/main/java/com/caixin/tree/ApiClient.java`

把第 12 行改成你的服务器地址：
```java
public static String BASE = "https://你的应用.onrender.com";
```
保存。

## 第三步：出 APK（三选一，都是免费的）

### 方法 A：GitHub 免费自动打包（推荐，纯手机可操作）

1. 手机浏览器打开 github.com 注册账号（免费）
2. 点右上角 + → New repository，仓库名随便起（如 caixin），点 Create
3. 进仓库后点「uploading an existing file」，把整个工程的文件按目录结构传上去
   （app、server、.github 这些目录都要传，注意 .github 是隐藏目录）
4. 传完后，GitHub 会自动运行打包（我们配好了 workflow）
5. 点仓库顶部的「Actions」标签 → 看到绿色 ✓ 表示成功
6. 点进去 → 页面底部「Artifacts」→ 下载「猜心圣诞树」
7. 解压 zip 得到 app-debug.apk，安装即可

> 上传目录结构麻烦的话，可以在电脑上用 git 一次传，或者
> 用手机上的 GitHub App + MT管理器配合。

### 方法 B：借一台电脑（最省事，5分钟）

学校机房/同学电脑装个免费 Android Studio，打开工程点 Build 就出 APK。

### 方法 C：手机 Termux 本地编译（进阶，全程手机）

```bash
# 1. 从 F-Droid 下载 Termux（免费）
# 2. 安装依赖
pkg update
pkg install openjdk-17 wget

# 3. 下载 Android 命令行工具
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip
# 4. 接受许可并装 build-tools/platform
yes | cmdline-tools/bin/sdkmanager --licenses
cmdline-tools/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0"

# 5. 下载 gradle
wget https://services.gradle.org/distributions/gradle-8.4-bin.zip
unzip gradle-8.4-bin.zip

# 6. 编译
export ANDROID_HOME=$PWD
./gradle-8.4/bin/gradle assembleDebug
# 产物在 app/build/outputs/apk/debug/app-debug.apk
```

## 第四步：发布新版本时的更新弹窗

更新弹窗已内置：App 启动会请求服务器 `/api/version`。
你要发新版本时，改后端 `server/server.js` 里的：
```js
let db = { users: {}, version: "1.0.1", apkUrl: "" };
```
把 `version` 改成新版本号，`apkUrl` 填新 APK 的下载直链。
用户打开旧版就会弹「发现新版本」。
