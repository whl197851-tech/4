/*
 * 猜心圣诞树 后端服务器 (Node.js, 零依赖)
 * 运行: node server.js   (默认端口 3000)
 * 数据: 存 data.json
 *
 * 接口:
 *   POST /api/register        {name}           -> {uid,name}
 *   POST /api/rename          {uid,name}       -> {ok}  (名字一次修改)
 *   POST /api/getme           {uid}            -> 用户信息
 *   POST /api/host/questions  {uid}            -> 某楼主的题目列表
 *   POST /api/host/add        {uid,text,options,answer} -> 添加题目
 *   POST /api/answer          {uid,name,answer} -> 提交一题答案
 *   GET  /api/host/tree       ?uid=xxx         -> 该楼主圣诞树排行榜
 *   GET  /api/version         -> {version,url}
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');

// ---------- 数据 ----------
let db = { users: {}, version: "1.0.1", apkUrl: "" };
if (fs.existsSync(DATA_FILE)) {
    try { db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) { }
}

function save() {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

function uid() {
    let id;
    do { id = String(Math.floor(100000 + Math.random() * 900000)); }
    while (db.users[id]);
    return id;
}

function userInfo(u) {
    return { uid: u.uid, name: u.name, nameChangeCount: u.nameChangeCount, qCount: u.questions.length };
}

// ---------- HTTP 工具 ----------
function readBody(req, cb) {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 1e6) req.destroy(); });
    req.on('end', () => {
        try { cb(JSON.parse(data || '{}')); } catch (e) { cb({}); }
    });
}

function send(res, obj) {
    res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*'
    });
    res.end(JSON.stringify(obj));
}

const server = http.createServer((req, res) => {
    if (req.method === 'OPTIONS') {
        res.writeHead(200, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*' });
        return res.end();
    }

    const url = new URL(req.url, 'http://x');
    const p = url.pathname;

    if (req.method === 'GET' && p === '/api/version') {
        return send(res, { version: db.version, url: db.apkUrl });
    }

    if (req.method === 'GET' && p === '/api/host/tree') {
        const uidv = url.searchParams.get('uid');
        const u = db.users[uidv];
        if (!u) return send(res, { ok: false, msg: '没有这个人' });
        return send(res, { ok: true, host: userInfo(u), players: u.players });
    }

    if (req.method === 'POST') {
        readBody(req, body => {
            if (p === '/api/register') {
                const name = String(body.name || '').trim();
                if (!name) return send(res, { ok: false, msg: '名字不能为空' });
                const id = uid();
                db.users[id] = { uid: id, name, nameChangeCount: 0, questions: [], players: [] };
                save();
                return send(res, { ok: true, uid: id, name });
            }

            if (p === '/api/rename') {
                const u = db.users[body.uid];
                if (!u) return send(res, { ok: false, msg: '没找到用户' });
                if (u.nameChangeCount >= 1) return send(res, { ok: false, msg: '名字只能改一次' });
                const name = String(body.name || '').trim();
                if (!name) return send(res, { ok: false, msg: '名字不能为空' });
                u.name = name;
                u.nameChangeCount++;
                save();
                return send(res, { ok: true, name });
            }

            if (p === '/api/getme') {
                const u = db.users[body.uid];
                if (!u) return send(res, { ok: false, msg: '没找到用户' });
                return send(res, { ok: true, user: userInfo(u) });
            }

            if (p === '/api/host/questions') {
                const u = db.users[body.uid];
                if (!u) return send(res, { ok: false, msg: '没有这个人' });
                return send(res, { ok: true, host: userInfo(u), questions: u.questions });
            }

            if (p === '/api/host/add') {
                const u = db.users[body.uid];
                if (!u) return send(res, { ok: false, msg: '没找到用户' });
                if (u.questions.length >= 100) return send(res, { ok: false, msg: '最多100题' });
                const text = String(body.text || '').trim();
                const options = body.options || [];
                const answer = parseInt(body.answer, 10) || 0;
                if (!text || options.length < 2) return send(res, { ok: false, msg: '题目和至少两个选项' });
                u.questions.push({ text, options, answer });
                save();
                return send(res, { ok: true, count: u.questions.length });
            }

            if (p === '/api/answer') {
                const u = db.users[body.uid];
                if (!u) return send(res, { ok: false, msg: '没有这个人' });
                const name = String(body.name || '访客').trim();
                const qIndex = parseInt(body.qIndex, 10) || 0;
                const answer = parseInt(body.answer, 10) || 0;
                const q = u.questions[qIndex];
                if (!q) return send(res, { ok: false, msg: '题目不存在' });

                let player = u.players.find(pl => pl.name === name);
                if (!player) { player = { name, score: 0, answered: 0 }; u.players.push(player); }
                player.answered++;
                const correct = (answer === q.answer);
                if (correct) player.score++;

                save();
                return send(res, { ok: true, correct, score: player.score, answered: player.answered, rightAnswer: q.answer });
            }

            return send(res, { ok: false, msg: '未知接口' });
        });
        return;
    }

    res.writeHead(404);
    res.end('not found');
});

server.listen(PORT, () => console.log('猜心圣诞树服务器已启动: http://0.0.0.0:' + PORT));
